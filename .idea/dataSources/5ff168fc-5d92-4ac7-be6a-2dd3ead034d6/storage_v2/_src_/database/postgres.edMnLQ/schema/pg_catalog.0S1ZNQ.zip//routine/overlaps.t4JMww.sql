create function "overlaps"(time without time zone, interval, time without time zone, interval) returns boolean
    immutable
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function "overlaps"(time with time zone, time with time zone, time with time zone, time with time zone) is 'intervals overlap?';

alter function "overlaps"(time with time zone, time with time zone, time with time zone, time with time zone) owner to postgres;

